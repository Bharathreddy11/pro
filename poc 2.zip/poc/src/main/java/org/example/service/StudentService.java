package org.example.service;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;

import org.example.repo.StudentRepository;

@RequestScoped
public class StudentService {

    @Inject
    private StudentRepository studentRepository;

    public void createStudent(String name, int age) {

        studentRepository.createStudent(name, age);
    }

    // Additional methods for business logic if needed
}
