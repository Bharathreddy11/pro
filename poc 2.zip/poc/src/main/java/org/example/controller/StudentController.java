package org.example.controller;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.MediaType;
import org.example.entity.Student;
import org.example.repo.StudentRepository;

@RequestScoped
@Path("/student")
public class StudentController {

    @Inject
    private StudentRepository studentRepository;
    @PersistenceContext(unitName = "pu1")
    private EntityManager entityManager;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Transactional(Transactional.TxType.REQUIRED)
    @Path("/save")
    public String saveStudent() {
        // Create a student (replace with actual data)
        Student studObj=new Student();
        studObj.setAge(25);
        studObj.setName("Bharath");

        try {
          entityManager.persist(studObj);

        } catch (Exception e) {
           e.printStackTrace();
        }

        return "Student created!";
    }

}
