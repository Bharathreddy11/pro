package org.example.controller;

import jakarta.enterprise.context.RequestScoped;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;

@RequestScoped
@Path("/hello")
public class HelloController {
    @GET
    public String hello(){
        return "Hello Bharath";
    }

//    @GET
//    public String wishme(){
//        return "Hello Bharath goodmorning";
//    }
//

}