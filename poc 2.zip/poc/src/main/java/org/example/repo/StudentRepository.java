package org.example.repo;

import jakarta.enterprise.context.RequestScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.example.entity.Student;

@RequestScoped
public class StudentRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    public void createStudent(String name, int age) {
        Student student = new Student();
        student.setName(name);
        student.setAge(age);

        entityManager.persist(student);
    }



    // Additional methods for querying, updating, and deleting students if needed
}
