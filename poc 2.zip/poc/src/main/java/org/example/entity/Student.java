package org.example.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity(name = "Student")
@Table(name = "Student")
@Access(AccessType.PROPERTY)
@NamedQueries({
        @NamedQuery(name = "getStudent",
                query = "SELECT p FROM Student p"),
        @NamedQuery(name = "getStudentByName",
                query = "SELECT p FROM Student p WHERE p.name = :name")
})
public class Student {

    private Long id;

    private String name;
    private int age;

    public Student(){}
    @Id
    @Column(name = "ID", nullable = false, updatable = false)
    public Long getId() {
        return id;
    }
    public void setId(Long id){
        this.id=id;
    }
    @Basic(optional = false)
    @Column(name = "NAME", nullable = false)
    public String getName() {
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
    @Id
    @Column(name = "AGE", nullable = false, updatable = false)
    public int getAge() {
        return age;
    }
    public void setAge(int age){
        this.age=age;
    }

    // Constructors, getters, and setters

}
